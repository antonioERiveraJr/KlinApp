package com.example.cleaningapplication.Interface;

import android.view.View;

public interface ItemCllickListener {

    void onClick(View view, int position, boolean isLongClick);
}
