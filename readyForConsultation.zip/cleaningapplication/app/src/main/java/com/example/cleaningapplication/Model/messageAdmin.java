package com.example.cleaningapplication.Model;

public class messageAdmin {


    String Sender;
    String Message;

    String Time;
    public String getSender() {
        return Sender;
    }

    public String getMessage() {
        return Message;
    }

    public String getTime() {
        return Time;
    }



}
