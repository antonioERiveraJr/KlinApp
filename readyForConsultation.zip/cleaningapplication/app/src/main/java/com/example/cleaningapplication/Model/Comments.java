package com.example.cleaningapplication.Model;

public class Comments {

    String From;
    String Message;
    String To;
    String Date;
    String FromImage;


    public String getMessage(){return Message;}

    public String getFrom() {
        return From;
    }

    public String getFromImage(){return FromImage;}

    public String getTo() {
        return To;
    }

    public String getDate() {
        return Date;
    }


}
