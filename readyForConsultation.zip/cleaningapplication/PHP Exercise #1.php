<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise7</title>
</head>
<style>
  .table {
  width:70%;
  background-color:yellow;
  border-spacing: 12px;
  border: 6px solid; }
</style>
<body>
<?php
echo "Twinkle, Twinkle little star.\n";
$first ="Twinkle";
$second ="star";
echo "$first, $first little $second.\n";
$first = "Yum";
$second = "balls.";
echo "$first, $first little $second.";
?>

</body>
</html>
